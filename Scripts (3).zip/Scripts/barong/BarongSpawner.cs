using Godot;
using System;

public partial class BarongSpawner : Node3D
{
    [Export] public PackedScene BarongScene;
    [Export] public int SpawnCount = 3;
    [Export] public Vector3 SpawnAreaSize = new Vector3(15, 4, 15);
    [Export] public float MinHeight = 0.0f;
    [Export] public float MaxHeight = 2.0f;
    [Export] public bool ShowDebugArea = true;
    
    private MeshInstance3D _debugMesh;
    
    public override void _Ready()
    {
        if (ShowDebugArea)
        {
            CreateDebugMesh();
        }
        
        SpawnBarongMonsters();
    }
    
    public void SpawnBarongMonsters()
    {
        if (BarongScene == null)
        {
            GD.PrintErr("BarongScene belum di-assign!");
            return;
        }
        
        for (int i = 0; i < SpawnCount; i++)
        {
            var barong = BarongScene.Instantiate<BarongMonster>();
            AddChild(barong);
            
            // Posisikan secara acak
            float halfWidth = SpawnAreaSize.X / 2;
            float halfLength = SpawnAreaSize.Z / 2;
            
            float randomX = (float)GD.RandRange(-halfWidth, halfWidth);
            float randomZ = (float)GD.RandRange(-halfLength, halfLength);
            float randomY = (float)GD.RandRange(MinHeight, MaxHeight);
            
            barong.Position = new Vector3(randomX, randomY, randomZ);
            barong.RotationDegrees = new Vector3(0, (float)GD.RandRange(0, 360), 0);
        }
    }
    
    private void CreateDebugMesh()
    {
        _debugMesh = new MeshInstance3D();
        BoxMesh boxMesh = new BoxMesh();
        boxMesh.Size = SpawnAreaSize;
        
        _debugMesh.Mesh = boxMesh;
        
        StandardMaterial3D material = new StandardMaterial3D();
        material.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
        material.AlbedoColor = new Color(0.8f, 0.2f, 0.2f, 0.2f); // Merah untuk monster
        
        _debugMesh.MaterialOverride = material;
        AddChild(_debugMesh);
    }
}