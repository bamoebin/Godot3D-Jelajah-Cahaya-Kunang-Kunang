using Godot;
using System;

public partial class KunangSpawner : Node3D
{
	[Export] public PackedScene KunangScene;
	[Export] public int SpawnCount = 10;
	[Export] public Vector3 SpawnAreaSize = new Vector3(10, 4, 10);
	[Export] public float MinHeight = 0.5f;
	[Export] public float MaxHeight = 3.0f;
	[Export] public bool ShowDebugArea = true;
	
	// Untuk debugging
	private MeshInstance3D _debugMesh;
	
	public override void _Ready()
	{
		if (ShowDebugArea)
		{
			CreateDebugMesh();
		}
		
		// Spawn kunang-kunang
		SpawnKunangKunang();
	}
	
	public void SpawnKunangKunang()
	{
		if (KunangScene == null)
		{
			GD.PrintErr("KunangScene belum di-assign!");
			return;
		}
		
		for (int i = 0; i < SpawnCount; i++)
		{
			// Instance kunang-kunang
			var kunang = KunangScene.Instantiate<KunangKunang>();
			AddChild(kunang);
			
			// Posisikan secara acak dalam area
			float halfWidth = SpawnAreaSize.X / 2;
			float halfLength = SpawnAreaSize.Z / 2;
			
			float randomX = (float)GD.RandRange(-halfWidth, halfWidth);
			float randomZ = (float)GD.RandRange(-halfLength, halfLength);
			float randomY = (float)GD.RandRange(MinHeight, MaxHeight);
			
			kunang.Position = new Vector3(randomX, randomY, randomZ);
			
			// Rotasi random untuk arah awal
			kunang.RotationDegrees = new Vector3(
				0, 
				(float)GD.RandRange(0, 360), 
				0
			);
		}
	}
	
	private void CreateDebugMesh()
	{
		// Buat mesh kotak transparan untuk visualisasi
		_debugMesh = new MeshInstance3D();
		BoxMesh boxMesh = new BoxMesh();
		boxMesh.Size = SpawnAreaSize;
		
		_debugMesh.Mesh = boxMesh;
		
		// Buat material transparan
		StandardMaterial3D material = new StandardMaterial3D();
		material.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
		material.AlbedoColor = new Color(0.2f, 0.8f, 0.2f, 0.2f);
		
		_debugMesh.MaterialOverride = material;
		AddChild(_debugMesh);
	}
	
	// Untuk debugging - tampilkan area spawn di editor
	public override void _Process(double delta)
	{
		if (Engine.IsEditorHint() && ShowDebugArea && _debugMesh == null)
		{
			CreateDebugMesh();
		}
	}
}
